1. Stoogesort program is made by navigating into ./stoogesort1 and typing make then stoogesort
2. Stoogesort runtime program is made by navigating into ./runtime and typing make then stoogesort